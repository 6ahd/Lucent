# -*- coding: utf-8 -*-
"""Lucent Library: remember where you stopped a film or episode, on this device.

Seren keeps its resume points on Trakt and only uses them when asked, and a library title (a .strm file) gave Kodi
nothing to remember: you always started at the beginning. So while a video plays, its position is written every
few seconds to addon_data/script.lucent.library/resume.json, keyed by what the video is (film: its TMDb / IMDb id;
episode: the series' id + season + episode - the same for a library title, a Seren row or the series page).

  - Stopped between 1 minute and 92 %: the point is kept, and the film / episode in the Kodi library gets it as its
    resume point too (so Kodi shows the progress bar and offers "Resume").
  - Watched to the end: the point is removed.
  - The same title starts again (from the library, a row, Seren ...) and it starts near the beginning: it jumps to
    the saved point, with a short notice. When Seren already resumed it, nothing happens.
"""
import json
import os
import time

import xbmc
import xbmcgui
import xbmcvfs

ADDON_ID = "script.lucent.library"
FILE = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}/resume.json")
NL = xbmc.getLanguage(xbmc.ISO_639_1) == "nl"
MIN_POS = 60            # seconds: earlier is not worth remembering
DONE = 92               # percent: later counts as watched
KEEP = 200              # at most this many points are kept (oldest go first)


def log(text):
    xbmc.log(f"[{ADDON_ID}] resume: {text}", xbmc.LOGINFO)


def rpc(method, params=None):
    try:
        res = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params or {}})))
        return res.get("result") or {}
    except Exception:  # noqa: BLE001
        return {}


def load():
    try:
        with open(FILE, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return {}


def save(data):
    try:
        if len(data) > KEEP:
            for key in sorted(data, key=lambda k: data[k].get("time", 0))[:len(data) - KEEP]:
                data.pop(key, None)
        os.makedirs(os.path.dirname(FILE), exist_ok=True)
        tmp = FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh)
        os.replace(tmp, FILE)
    except OSError as error:
        log(f"save: {error}")


def ids_key(uniqueid):
    for name in ("tmdb", "imdb", "tvdb", "trakt"):
        value = str((uniqueid or {}).get(name) or "")
        if value and value not in ("0", "None"):
            return f"{name}{value}"
    return ""


def tag_ids(tag):
    out = {}
    for name in ("tmdb", "imdb", "tvdb", "trakt"):
        try:
            value = tag.getUniqueID(name)
        except Exception:  # noqa: BLE001
            value = ""
        if value:
            out[name] = value
    return out


def playing_item(player):
    """(key, info) of the video that plays, or ("", {}). Read from what the player plays (the list item Seren or
    the library gave it), with Kodi's library for the series of a library episode."""
    try:
        tag = player.getVideoInfoTag()
    except RuntimeError:
        return "", {}
    kind = tag.getMediaType() or ""
    ids = ids_key(tag_ids(tag))
    dbid = tag.getDbId() or -1
    season, episode, show = tag.getSeason(), tag.getEpisode(), tag.getTVShowTitle()
    if kind == "episode" or (season >= 0 and episode > 0 and show):
        show_ids = ""
        if dbid and dbid > 0:                                           # a library episode: the series' own ids
            ep = rpc("VideoLibrary.GetEpisodeDetails", {"episodeid": dbid, "properties": ["tvshowid"]}).get("episodedetails") or {}
            if ep.get("tvshowid", -1) > 0:
                tv = rpc("VideoLibrary.GetTVShowDetails", {"tvshowid": ep["tvshowid"], "properties": ["uniqueid"]}).get("tvshowdetails") or {}
                show_ids = ids_key(tv.get("uniqueid"))
        show_ids = show_ids or ids or f"title{(show or '').lower()}"
        return f"ep:{show_ids}:{season}:{episode}", {"kind": "episode", "show": show, "season": season, "episode": episode}
    if not ids and dbid and dbid > 0 and kind == "movie":
        mv = rpc("VideoLibrary.GetMovieDetails", {"movieid": dbid, "properties": ["uniqueid"]}).get("moviedetails") or {}
        ids = ids_key(mv.get("uniqueid"))
    if ids:
        return f"movie:{ids}", {"kind": "movie", "title": tag.getTitle()}
    return "", {}


def _dexhub_started(within):
    """Dex Hub handed a playback to Kodi in the last `within` seconds."""
    try:
        raw = xbmcgui.Window(10000).getProperty("dexhub.play.handoff") or ""
        stamp = float(raw.rpartition("#")[2])
        return 0 <= time.time() - stamp < within
    except (ValueError, TypeError):
        return False


class Keeper:
    """Called from the service: started(), tick() every second, stopped()."""

    def __init__(self, player):
        self.player = player
        self.key, self.info = "", {}
        self.pos = self.total = 0.0
        self.last_write = 0.0
        self.checked = False
        self.since = 0.0

    def started(self):
        # A playback Dex Hub started: Dex Hub keeps and resumes its own place, so this one leaves it
        # alone (no second jump, no "Continuing from" notice). Dex Hub sets dexhub.play.handoff,
        # '<key>#<time>', for every play it hands to Kodi (Floppy reads it the same way).
        if _dexhub_started(120):
            self.key, self.info = "", {}
            log("started by Dex Hub, which resumes it itself: left alone")
            return
        self.key, self.info = playing_item(self.player)
        self.pos = self.total = 0.0
        self.checked = False
        self.since = time.time()
        log(f"playing {self.key or '(unknown)'}")

    def tick(self):
        if not self.key:
            return
        try:
            if not self.player.isPlayingVideo():
                return
            self.pos, self.total = self.player.getTime(), self.player.getTotalTime()
        except RuntimeError:
            return
        if not self.checked and self.total > 0 and time.time() - self.since > 4:   # Seren / Kodi resume first
            self.checked = True
            self.jump()
        if time.time() - self.last_write > 15:
            self.last_write = time.time()
            self.store()

    def jump(self):
        """Started near the beginning while a point is saved: go there."""
        point = load().get(self.key) or {}
        target = float(point.get("pos") or 0)
        if target < MIN_POS or self.pos > 45 or abs(self.pos - target) < 30:
            return                                   # nothing saved, or Seren / Kodi already resumed it
        if self.total and target > self.total * DONE / 100:
            return
        self.player.seekTime(max(0.0, target - 5))
        mins, secs = divmod(int(target), 60)
        hours, mins = divmod(mins, 60)
        stamp = f"{hours}:{mins:02d}:{secs:02d}" if hours else f"{mins}:{secs:02d}"
        xbmcgui.Dialog().notification("Lucent", (f"Verder vanaf {stamp}" if NL else f"Continuing from {stamp}"),
                                      xbmcgui.NOTIFICATION_INFO, 3000)
        log(f"jumped to {stamp} for {self.key}")

    def store(self, final=False):
        if not self.key or self.total <= 0:
            return
        data = load()
        pct = self.pos / self.total * 100
        if pct >= DONE:
            if data.pop(self.key, None) is not None:
                save(data)
            if final:
                self.library(0, 0)
            return
        if self.pos < MIN_POS:
            return
        data[self.key] = {"pos": round(self.pos, 1), "total": round(self.total, 1), "time": time.time(), **self.info}
        save(data)
        if final:
            self.library(self.pos, self.total)

    def stopped(self):
        if self.key:
            self.store(final=True)
            log(f"stopped {self.key} at {int(self.pos)} of {int(self.total)} s")
        self.key = ""

    def library(self, pos, total):
        """The same point as Kodi's own resume point of the library title (progress bar, 'Resume')."""
        resume = {"position": round(pos, 1), "total": round(total, 1)}
        try:
            if self.info.get("kind") == "movie":
                want = self.key.split(":", 1)[1]
                for m in rpc("VideoLibrary.GetMovies", {"properties": ["uniqueid", "file"]}).get("movies") or []:
                    if ADDON_ID in (m.get("file") or "") and any(f"{k}{v}" == want for k, v in (m.get("uniqueid") or {}).items()):
                        rpc("VideoLibrary.SetMovieDetails", {"movieid": m["movieid"], "resume": resume})
                        return
            elif self.info.get("kind") == "episode":
                _ep, show, season, episode = self.key.split(":", 3)
                for s in rpc("VideoLibrary.GetTVShows", {"properties": ["uniqueid"]}).get("tvshows") or []:
                    if any(f"{k}{v}" == show for k, v in (s.get("uniqueid") or {}).items()):
                        eps = rpc("VideoLibrary.GetEpisodes", {"tvshowid": s["tvshowid"], "season": int(season),
                                                               "properties": ["episode", "file"]}).get("episodes") or []
                        for e in eps:
                            if str(e.get("episode")) == str(episode) and ADDON_ID in (e.get("file") or ""):
                                rpc("VideoLibrary.SetEpisodeDetails", {"episodeid": e["episodeid"], "resume": resume})
                                return
        except Exception as error:  # noqa: BLE001
            log(f"library point: {error}")
